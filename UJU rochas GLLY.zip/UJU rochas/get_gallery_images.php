<?php
header('Content-Type: application/json');

// Scan the glly folder for all images
$folder = __DIR__ . '/glly';
$images = array();

if(is_dir($folder)){
    $files = scandir($folder);
    foreach($files as $file){
        if($file !== '.' && $file !== '..'){
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if(in_array($ext, array('jpg', 'jpeg', 'png', 'gif', 'webp'))){
                $images[] = 'glly/' . $file;
            }
        }
    }
}

// Also add static images
$staticImages = array(
    'hero3.jpg',
    'Abia%20State.jpeg',
    'abiaaa.jpg',
    'close-up-hands-holding-outdoors.jpg',
    'nutr774.webp',
    'QOUTES.png',
    'uju hero image.png',
    'main bg.jpg',
    'medium-shot-smiley-african-boys.jpg',
    'GALLERY IMAGE 1.jpg'
);

// Combine static images with scanned images
$allImages = array_merge($staticImages, $images);

echo json_encode($allImages);
?>
